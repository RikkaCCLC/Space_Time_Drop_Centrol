package com.george.centrol.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.george.centrol.pojo.Centrol;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CentrolMapper extends BaseMapper<Centrol> {
}
