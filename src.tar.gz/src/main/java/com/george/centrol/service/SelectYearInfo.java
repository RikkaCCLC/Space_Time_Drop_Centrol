package com.george.centrol.service;

public interface SelectYearInfo {
    public String getYearInfo();
}
