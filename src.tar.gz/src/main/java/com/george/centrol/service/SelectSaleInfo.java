package com.george.centrol.service;

import com.george.centrol.pojo.SaleInfo;

import java.util.List;

//获取销售信息
public interface SelectSaleInfo {
    public List<SaleInfo> getSaleInfoList();
}
