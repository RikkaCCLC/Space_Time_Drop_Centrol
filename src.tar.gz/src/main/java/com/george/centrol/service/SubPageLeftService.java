package com.george.centrol.service;

import com.alibaba.fastjson2.JSONObject;

import java.util.Map;

public interface SubPageLeftService {
    JSONObject getFullList(Map<String, String> map);
}
