package com.george.centrol.service;

import java.util.List;
import java.util.Map;

//获取运营车辆
public interface SelectCarNum {
    public List<Map<String,String>> getCarNum();
}
