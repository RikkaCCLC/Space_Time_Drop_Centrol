package com.george.centrol.service;

import java.util.List;
import java.util.Map;

//获取门店数量
public interface SelectStoreNum {
    public List<Map<String,String>> getStoreNum();
}
