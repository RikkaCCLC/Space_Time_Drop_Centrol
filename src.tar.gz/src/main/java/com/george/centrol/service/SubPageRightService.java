package com.george.centrol.service;

import com.george.centrol.pojo.SaleInfo;

import java.util.List;

public interface SubPageRightService {
    List<SaleInfo> getNewSale();
}
