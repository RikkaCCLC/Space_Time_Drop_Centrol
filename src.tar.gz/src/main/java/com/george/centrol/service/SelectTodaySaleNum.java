package com.george.centrol.service;

import java.util.List;
import java.util.Map;

//获取今日销量
public interface SelectTodaySaleNum {
    public List<Map<String, String>> selectTodaySaleNum();
}
